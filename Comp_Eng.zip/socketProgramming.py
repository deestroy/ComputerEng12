import ipFinder
import shutil
import clientSendFile
import serverSendFile
import playerGames
host=''
port = 5560
def main():
  ipOfNode = ipFinder.get_lan_ip()
  if (ipOfNode == "192.168.0.110"):
        print("I am a client Network")
        shutil.copy2('/home/pi/coordinates.txt', '/home/pi/fileToServer.txt') # complete target filename given
        clientSendFile.TransferFileToServer('192.168.0.104', '/home/pi/fileToServer.txt')
        serverSendFile.TransferFileToClient('','/home/pi/fileToClient.txt')
        playerGames.call_read_in_opponent_data('/home/pi/fileToServer.txt')
        playerGames.call_read_my_own_data('/home/pi/coordinates.txt')
        playerGames.ObtainUserInput()
        
        print (" OK WE ARE READY TO PLAY")
  else :
        print("I am a server network")
        shutil.copy2('/home/pi/coordinates.txt', '/home/pi/fileToClient.txt')
        serverSendFile.TransferFileToClient('','/home/pi/fileToServer.txt')
        clientSendFile.TransferFileToServer('192.168.0.110', '/home/pi/fileToServer.txt')
        playerGames.call_read_in_opponent_data('/home/pi/fileToClient.txt')
        playerGames.call_read_my_own_data('/home/pi/coordinates.txt')
        playerGames.ObtainUserInput()
        print (" OK WE ARE READY TO PLAY")

if __name__ == "__main__":
    main()
