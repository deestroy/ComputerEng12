import time
from neopixel import *
#import argparse
import RPi.GPIO as GPIO
import bs

buttonR = 11
buttonL = 13
buttonD = 18
buttonU = 16
buttonSel = 22

#LED Strip Configuration

LED_COUNT      = 81      # Number of LED pixels.
LED_PIN        = 18      # GPIO pin connected to the pixels (18 uses PWM!).
#LED_PIN        = 10     # GPIO pin connected to the pixels (10 uses SPI /dev/spidev0.0).
LED_FREQ_HZ    = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA        = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 170     # Set to 0 for darkest and 255 for brightest
LED_INVERT     = False   # True to invert the signal (when using NPN transistor level shift)
LED_CHANNEL    = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53

BUTTON_INPUTR   = False
BUTTON_INPUTL   = False
BUTTON_INPUTD   = False
BUTTON_INPUTU   = False
BUTTON_SELECTION = False

#Setting things up for the Button
GPIO.setmode(GPIO.BOARD)
GPIO.setup(buttonR , GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(buttonL , GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(buttonD , GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(buttonU , GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(buttonSel , GPIO.IN, pull_up_down=GPIO.PUD_UP)


strip=[81]
ledPos = 0
selCounter = 1
firstXLocation = 0
secondXLocation = 0
firstYLocation = 0
secondYLocation = 0
ledFirst = 0
ledSecond = 0 

# this to light up Individual cors
def colorWipe(strip, color,wait_ms=50):
   #for i in range(strip.numPixels()):
   for i in range(LED_COUNT):
        strip.setPixelColor(i,color)
        strip.show()
   myboard= bs.displayPlayer(True)
   displayBoardContent(myboard, strip)

def displayBoardContent(myboard, strip):
  for i in range(9):
    for j in range(9):
     if(myboard[i][j] == '@'):
       a = i * 9 + j
       strip.setPixelColor(a, Color(225,8,225))
       strip.show()

def colorWipeSpecific(strip, location):
     strip.setPixelColor(location, Color(0,0,0))
     strip.show()
     myboard= bs.displayPlayer(True)
     displayBoardContent(myboard, strip)


def writecooridatesToFile():
  #program is to  set a coordinates to file
  file = open("coordinates.txt","w")  
  myPlayerData = bs.displayPlayer(True)
  test_string=""
  for i in range(9):
     for j in range(9):
       if(myPlayerData[i][j]== '@'):
         test_string=test_string+str(i)+","+str(j)+":"
           
  file.write(test_string)
  file.close()


#    for j in 81:
#        strip.add(j - 1)


def button():
    global BUTTON_INPUTR
    global BUTTON_INPUTL
    global BUTTON_INPUTU
    global BUTTON_INPUTD
    global BUTTON_SELECTION

    if(GPIO.input(buttonR)==False):
        BUTTON_INPUTR = True
    else:
        BUTTON_INPUTR = False

    if(GPIO.input(buttonL)==False):
        BUTTON_INPUTL = True
    else:
        BUTTON_INPUTL = False

    if(GPIO.input(buttonD)==False):
        BUTTON_INPUTD = True
    else:
        BUTTON_INPUTD = False

    if(GPIO.input(buttonU)==False):
        BUTTON_INPUTU = True
    else:
        BUTTON_INPUTU = False

    if(GPIO.input(buttonSel)==False ):
        BUTTON_SELECTION = True
    else:
        BUTTON_SELECTION = False


def setColour(strip, color, wait_ms=50):
    global ledPos
    global selCounter
    global BUTTON_SELECTION
    global firstXLocation
    global firstYLocation
    global secondXLocation
    global secondYLocation
    global ledFirst
    global ledSecond

    if(BUTTON_INPUTR == True):
        if(selCounter == 1):
         colorWipe(strip, Color(0,0,0))
        if(ledPos < 81):
          print(str(ledPos))
          if(ledPos<ledFirst):
            colorWipeSpecific(strip, ledPos)
          ledPos = ledPos + 1
          strip.setPixelColor(ledPos, color)
          strip.show()
          time.sleep(wait_ms/1000.0)
        return True
    elif(BUTTON_INPUTL == True):
        if(selCounter == 1):
         colorWipe(strip, Color(0,0,0))
        if(ledPos > 0) and (ledPos <81):
          if (ledPos > ledFirst): 
           colorWipeSpecific(strip, ledPos)
          ledPos = ledPos - 1
          strip.setPixelColor(ledPos, color)
          strip.show()
          time.sleep(wait_ms/1000.0)
        return True
    elif(BUTTON_INPUTD == True):
        if (ledPos<72):
         if(selCounter == 1):
          colorWipe(strip, Color(0,0,0))
         if (ledPos<ledFirst):
           colorWipeSpecific(strip,ledPos)
         ledPos = ledPos + 9
         strip.setPixelColor(ledPos, color)
         strip.show()
         time.sleep(wait_ms/1000.0)
        return True
    elif(BUTTON_INPUTU == True):
        if(ledPos>8):
         if(selCounter == 1):
          colorWipe(strip, Color(0,0,0))
         if(ledPos >ledFirst):
           colorWipeSpecific(strip, ledPos)
         ledPos = ledPos - 9
         strip.setPixelColor(ledPos, color)
         strip.show()
         time.sleep(wait_ms/1000.0)
        return True
    elif(BUTTON_SELECTION == True and  selCounter == 1):
        print (" first location selection")
        firstXLocation = ledPos/9
        firstYLocation = ledPos%9
        ledFirst = ledPos
        #ledPos = 0
        #BUTTON_SELECTION = False
        selCounter = selCounter +1
        time.sleep(0.5)
        return True
    elif(BUTTON_SELECTION == True  and selCounter == 2 ):
        selCounter = selCounter +1
        BUTTON_SELECTION = False
        return True
    elif(BUTTON_SELECTION == True):
        print (" second location selection")
        secondXLocation = ledPos/9
        secondYLocation = ledPos%9
        return False
    else:
        #print("correct button not pressed")
        return True

def dispplayCurrentShips():
    stripS = Adafruit_NeoPixel(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
    stripS.begin()
    


def ObtainUserInput():
    strip = Adafruit_NeoPixel(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
    strip.begin()
    global strip
    print("ObtainUserInout")
    continueInput = True
    global firstXLocation
    global firstYLocation
    global secondXLocation
    global secondYLocation
    global ledPos
    global selCounter
    global ledFirst
    global ledSecond
    colorWipe(strip, Color(0,0,0))
    print("ask entry")
    ledPos = 0
    selCounter = 1 
    strip.setPixelColor(0, Color(90,40,40))
    strip.show()
    while continueInput:
        button()
        continueInput = setColour(strip, Color(90, 40, 40))
    print( " (X1 ="+ str(int(firstXLocation)) +"Y1 ="+ str(int(firstYLocation))+")" )
    print( " (X2 ="+ str(int(secondXLocation))+ "Y2 ="+ str(secondYLocation)+")")
    invalidData = bs.validatePlayerCordinates(int(firstXLocation), int(firstYLocation), int(secondXLocation), int(secondYLocation))
    print("Valid Coordinates :"+ str(invalidData))
    if (invalidData == False) and (bs.printTargetCountsLeft() == 0):
      colorWipe(strip,Color(0,75,200))
      time.sleep(0.5)
      print("I am here and done")
    elif(invalidData == False):
      colorWipe(strip,Color(225,0,0))
      time.sleep(0.5)
    else :
      colorWipe(strip,Color(0,255,0))
    
    return True

def main():
    #global strip
    #strip = Adafruit_NeoPixel(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
    #strip.begin()
    remShip = 1
    while (remShip >= 0):
        remShip = bs.printTargetCountsLeft()
        print(" Got Here")
        ObtainUserInput()
        print("Got Here")
        if (remShip == 0):
         break
    writecooridatesToFile()


if __name__ == "__main__":
    main()
