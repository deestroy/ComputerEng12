
import socket

def TransferFileToServer(host, text_file):
 #host = '192.168.0.104'
 port = 5560

 csFT = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
 csFT.connect((host, port))

 #text_file = '/home/pi/fileToServer.txt'
 #Send file
 with open(text_file, 'rb') as fs:
    #Using with, no file close is necessary,
    #with automatically handles file close
    data = fs.read(1024)
    while data:
        print('Sending data', data.decode('utf-8'))
        csFT.send(data)
        print('Sent data', data.decode('utf-8'))
        data = fs.read(1024)
        fs.close()
    print("Done Sending")
 csFT.close()
