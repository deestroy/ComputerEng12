import socket

def TransferFileToClient(host, text_file ):
# host = ''
 port = 5560

 ssFT = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
 ssFT.bind((host, port))
 ssFT.listen(1)
 (conn, address) = ssFT.accept()
 print (" Connection Accepted")
 #text_file = '/home/pi/fileToServer.txt'
 #Receive, output and save file
 with open(text_file, "wb") as fw:
        print("Receiving..")
        data = conn.recv(1024) 
        #data.decode('utf-8')
        # Split the data such that you separate the command
        # from the rest of the data.
        #dataMessage = data.split(' ', 1)
        #command = dataMessage[0]
        while data:
            print('receiving')
            print (data)
            fw.write(data)
            data = conn.recv(1024)
            if not data:
                print (" No content in data")
                break
            if data == 'EXIT':
                print (" No data")
                break

 fw.close()
 print("Received..")

