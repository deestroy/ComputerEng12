from random import randint
# board (predefined as 9 * 9 --> cannot change)
#import switcher
# declare and initialize the 2 dimensional boards
from neopixel import *
w, h = 9, 9;
board = [["0" for x in range(w)] for y in range(h)] # stores coordintes during game
playerBoard = [["0" for x in range(w)] for y in range(h)] # stores players coordinates
opponentBoard = [["0" for x in range(w)] for y in range(h)] # stores opponents coordintes

airCraft = 4   # Occupies 1 cell
patrolBoat = 3 # Occupies 2 cell
battleShip = 2 # Occupies 3 cell
destroyer = 1  # Occupies 4 cell

#define the LED Neopixel for Player strip
LED_COUNT = 81
LED_PIN = 18
LED_FREQ_HZ = 800000
LED_DMA = 10
LED_INVERT = False
LED_BRIGHTNESS = 190
LED_CHANNEL= 0

#define  global count of ships to keep track
def globalShipCounts():
 global airCraft
 global patrolBoat
 global battleShip
 global destroyer


globalShipCounts()

ships = {
    'Aircraft' : 4,
    'Patrol Boat' : 3,
    'Battleship' : 2,
    'Destroyer' : 1
    }

# Print the different arry entries
def print_board(arrayContent):
   for col in arrayContent:
       print (" ".join(col))

#print_board(board)


def printTargetCountsLeft():
    print ("AirCraft= "+str(airCraft))
    print ("Partol Boat = "+str(patrolBoat))
    print ("Battle Ship = "+str(battleShip))
    print ("Destroyer = "+str(destroyer))
    return (airCraft+patrolBoat+battleShip+destroyer)


#printTargetCountsLeft()

#Validate and Decrement the counter of ships

def decrementShipCounter(diff):
 global airCraft
 global patrolBoat
 global battleShip
 global destroyer
 diff = abs(diff)+1
 if (diff == 2) and (patrolBoat>0):
    patrolBoat = patrolBoat -1
    return True
 elif (diff == 3) and (battleShip > 0):
     battleShip = battleShip -1
     return True
 elif (diff == 4) and (destroyer > 0):
     destroyer = destroyer-1
     return True
 return False


def validatePlayerCordinates(startXVal,startYVal,endXVal,endYVal):
    #valid = True
    print (str(startXVal)+","+ str(startYVal))
    valid = updatePlayerCoordinates(startXVal, startYVal, endXVal, endYVal)
    return valid

def validateOpponentCoodiantes(startXVal,startYVal,endXVal,endYVal):
    print (str(startXVal)+","+ str(startYVal))
    vaild = updateSelectionData(startXVal,startYVal,endXVal,endYVal)
    return valid

#Enter the player coordinates
def updatePlayerCoordinates(startXVal,startYVal,endXVal,endYVal):
    print ("Comes here")
    global airCraft
    retVal= False
    if (endXVal == startXVal) and (endYVal == startYVal):
     print("this is an Aircraft that takes only one value")
      # decrement the count of aircraft
     if(airCraft > 0):
        airCraft = airCraft-1
        playerBoard[startXVal][startYVal] = '@'
        retVal=True
    elif (endXVal == startXVal):
     print(" the ship is placed horizontally")
     retVal = decrementShipCounter((endYVal-startYVal))
    elif (endYVal == startYVal):
     print(" the ship is placed vertically")
     retVal = decrementShipCounter((endXVal-startXVal))

    if (retVal):
     # print( retVal)
      if(startXVal > endXVal):
        star = endXVal
        endXVal = startXVal
        startXVal = star
      if(startYVal > endYVal):
        star = endYVal
        endYVal = startYVal
        startYVal = star
      for i in range (startXVal,endXVal+1):
        for j in range (startYVal,endYVal+1):
          playerBoard[i][j] = '@'

    return retVal

def displayPlayer(playerT):
   if (playerT==True):
    return playerBoard
   else:
    return opponentBoard


def coordinatesHit():
    # iterates through the opponent array, even if there is one entry that has an @ symbol then there are targets to be still hit
    count = 0
    for i in range (0,8):
      for j in range (0,8):
        if opponentBoard[i][j] == '@' :
           count = count + 1
    print( " The total count of :"+ str(count))

    if (count > 0):
        return True
    else:
        return False




#read in opponent coordinates from file // may be used only for test purpose
def readInOpponentData(startXValue,startYValue):
       opponentBoard[startXValue][startYValue] = '@'

def readInPlayerdata(startXValue, startYValue):
       playerBoard[startXValue][startYValue] = '@'

#readInOpponentData(1,2,1,2)
#readInOpponentData(1,3,1,6)
#readInOpponentData(2,2,5,2)
#print_board(opponentBoard)
# based on the coordinates selected mark hit vs miss on board
# if the target is completely or partially hit mark it with a charater x
# if it is a miss then update the array as $
# Parameters fro this funcation is xValue, yValue and Boolean is hit vs miss
def updateHitAndMissUpdates(xValue, yValue, isHit):
  if(isHit):
    playerBoard[xValue][yValue]='x'
  else:
    playerBoard[xValue][yValue]='$'

#select ships of opponent
def updateSelectionData(startXValue,startYValue,endXValue,endYValue):
  # Confirm that the rt number of cells are
  # Need to ensure that selection data matches the data of the opponent
  if (endXValue == startXValue) and (endYValue == startYValue):
    if(opponentBoard[startXValue][startYValue]=='@'):
      updateHitAndMissUpdates(startXValue, startYValue, True)
    else:
       updateHitAndMissUpdates(startXValue, startYValue, False)
    return true
  else:
    print("Multiple Selections are not valid")


#updateSelectionData(1,2,1,2)
#updateSelectionData(1,3,1,6)
#updateSelectionData(2,2,3,2)
# print_board(board)



#
def shoot(board):
    print (" Entering program")
    while True:
        try:
            user_corx = int(input("Enter the x value")) - 1
            user_cory = int(input("Enter the y value")) - 1
        except ValueError:
            print("Not a valid number")
            continue
        if(user_corx < 9 and user_cory < 9 and user_corx >= 0 and user_cory >= 0):
            if board[user_corx][user_cory] == 'O':
                board[user_corx][user_cory] = '$'
                return False
            elif board[user_corx][user_cory] == '$' or board[user_corx][user_cory] == 'X':
                print("Try Again")
            else:
                board[user_corx][user_cory] = 'X'
                for x in range(9):
                    for y in range(9):
                        if board[x][y] == '@':
                          print("Opponent turn")
                          return False
                        else:
                         print("I win!")
                         return True

#shoot(board)
#place ships
def place_ships(board):
    tile = 0
    user_corx = int(input("Enter the x value")) - 1
    user_cory = int(input("Enter the y value")) - 1
    if(user_corx < 9 and user_cory < 9 and user_corx >= 0 and user_cory >= 0):
            if ships[item] == 0:
                print("Placement is done")
            elif board[user_corx][user_cory] == 'X' or '$' or '@' :
                print("Invalid")

            for item in 4:
                if ships[item] == 0:
                    print("Placement is done")
                else:
                    print("Place another tile on same ship? (y/n)")
                    next_tile = str(raw_input(Y/N))



def check(tile):
     while switch(tile):
         if case(1):
             if ships['Aircraft'] == 0:
                 return False
             else:
                 ships['Aircraft'] -= 1
                 return True
             break
         if case(2):
              if ships['Patrol Boat'] == 0:
                  return False
              else:
                  ships['Patrol Boat'] -= 1
                  return True
              break
         if case(3):
              if ships['Battleship'] == 0:
                 return False
              else:
                 ships['Battleship'] -= 1
                 return True
              break
         if case(4):
              if ships['Destroyer'] == 0:
                  return False
              else:
                  ships['Destroyer'] -= 1
                  return True
              break
         print ("Done")
         break
